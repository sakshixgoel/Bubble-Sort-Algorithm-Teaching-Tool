let table;
let buzzer;
let cubes = [];
let textArray = [];
let numbersText;
let pointer;
let tourguide;
let screen; //controls which screen it is on
let buttonFont;
let titleFont;
let normalFont;
let timer = 100;
let tempBox;
let speechBubble;
let codeImage;
let cubeCoordinates = [];
let screenTimer = 0;
let moveTimer = 0;
let end;
let iVariable;

function setup() {
  createCanvas(900, 600);
  //Initalizing all objects
  screen = new Screen("home");
  textArray = ["Welcome to Cube Sort! A Rubik’s Cubing Contest just finished and you're going to help us sort the placement of the cubes! We're going to use the bubble sort technique to sort the Rubik’s cubes from least completed cube to most completed cube (the winner!)", "The first cube with an index of 0 is compared to the cube with an index of 1. As the first cube has one less square out of place in comparison to the second cube, it moves to the temp box. The second cube takes the place of the first, gaining an index of 0. The other cube fills the empty slot, gaining an index of 1.", "Next, the cube in index 1 is compared to the cube in index 2, since cube 1 has 3 pieces out of place and cube 2 has 2 pieces out of place no changes are made.","The cubes in index 2 and 3 are compared, since the cube in index 3 has no pieces out of place and the cube in index 2 has 2 pieces out of place, no changes occur.", "After, the cubes in index 3 and 4 are compared. Since the index 4 cube has more pieces out of place than the index 3 cube has, the index 3 cube moves into the temp box while the index 4 cube will shift 1 space to the left. The temp cube moves into the empty space at index 4.", "Next, the cubes at index 4 and 5 are compared. Since the cube at index 5 has 1 piece out of place while the other cube is perfect, the cube at index 4 moves into the temp box while the cube in index 5 shifts 1 position left and the current temp cube moves into the empty space at index 5",  "Now, the cubes in index 5 and 6 are compared, the cube at index 6 has more pieces out of place than the cube at index 5 does, therefore the cube at index 5 moves into the temp box while the cube at index 6 moves into index 5. Then the cube in temp moves into the empty slot at index 6.", "Then, the cubes in index 6 and 7 are compared. The cube at index 7 has more pieces out of place than the cube at index 6 does. Therefore, the cube at index 6 moves into the temp box while the cube at index 7 moves 1 slot left to index 6 and the temp cube moves into the empty slot at index 7.",  "The last check for the run compares the cubes at index 7 and 8. Since the cube at index 8 has more pieces out of place than index 7 has, the cube at index 7 moves into the temp box while the cube at index 8 moves 1 slot left to index 7. Then the temp cube moves into the empty slot of index 8. The end moves in front of index 8 and the loop restarts.", "The index is set back to 0 and the cubes at index 0 and 1 are compared. Since the cube at index 1 has less pieces out of place than the cube at 0, no changes are made.", "Next, the cubes at index 1 and 2 are compared. The cube at index 2 has less pieces out of place, therefore no changes are made.", "Now, the cubes at index 2 and 3 are compared. Since the cube at index 3 had more pieces out of place than the cube at index 2, the cube at index 2 moves into the temp box while the cube at index 3 moves into index 2. Then the temp cube moves into the empty slot at index 3.", "Then, the cubes at index 3 and 4 are compared. Since the cube at index 3 has more pieces out of place than the cube at index 4, no changes are made.", "The cubes at index 4 and 5 are compared. Since the cube at index 5 has more pieces out of place than the cube at index 4 has, the cube at index 4 moves into the temp box while the cube at index 5 shifts to the position of index 4. Then the temp cube moves into the empty slot at index 5.", "The cubes at index 5 and 6 are compared. As the cube in index 5 only has one piece out of place, the cube in index 5 moves to the temp box. The other cube takes its place gaining an index of 5 and the cube in the temp box becomes index 6.", "The cubes at index 6 and 7 are compared. As the cube in index 6 only has less pieces out of place, the cube in index 6 moves to the temp box. The other cube takes its place gaining an index of 6 and the cube in the temp box becomes index 7. The end moves in front of index 7 and the loop restarts.", "The cube at index 0 has more pieces out of place than the cube at index 1, so no changes are made.", "The cube at index 2 has more pieces out of place than the cube at index 1, so the cube at index 1 moves to the temp box. The cube at index 2 shifts over to gain an index of 1 and the cube in the temp box gains an index of 2.", "The cube at index 2 has more pieces out of place than the cube at index 3, so no changes are made.", "The cube at index 4 has more pieces out of place than the cube at index 3, so the cube at index 3 moves to the temp box. The cube at index 4 shifts over to gain an index of 3, and the cube in the temp box gains an index of 4.", "The cube at index 5 has more pieces out of place than the cube at index 4, so the cube at index 4 moves into the temp box. The cube at index 5 shifts over to gain an index of 4 and the cube in the temp box gains an index of 5.", "The cube at index 6 has more pieces out of place than the cube at index 5, so the cube at index 5 moves to the temp box. The cube at index 6 shifts over to gain an index of 5, and the cube in the temp box gains an index of 6. The end moves in front of index 6, and the loop restarts.", "The cube at index 1 has more pieces out of place than the cube at index 0, so the cube at index 0 moves to the temp box. The cube at index 1 shifts over to gain an index of 0, and the cube in the temp box gains an index of 1.", "The cubes at index 1 and 2 are in the correct order (most to least pieces out of place) so no changes are made.", "The cube at index 3 has more pieces out of place than the cube at index 2, so the cube at index 2 moves into the temp box. The cube at index 3 shifts over to gain an index of 2 and the cube in the temp box gains an index of 3.", "The cube at index 4 has more pieces out of place than the cube at index 3, so the cube at index 3 moves into the temp box. The cube at index 4 shifts over to gain an index of 3 and the cube in the temp box gains an index of 4.", "The cube at index 5 has more pieces out of place than the cube at index 4, so the cube at index 4 moves into the temp box. The cube at index 5 shifts over to gain an index of 4 and the cube in the temp box gains an index of 5. The end moves in front of index 5, and the loop restarts.", "The cubes at index 0 and 1 are in the correct order (most to least pieces out of place) so no changes are made.", "The cube at index 2 has more pieces out of place than the cube at index 1, so the cube at index 1 moves into the temp box. The cube at index 2 shifts over to gain an index of 1 and the cube in the temp box gains an index of 2.", "The cube at index 3 has more pieces out of place than the cube at index 2, so the cube at index 2 moves into the temp box. The cube at index 3 shifts over to gain an index of 2 and the cube in the temp box gains an index of 3.", "The cube at index 4 has more pieces out of place than the cube at index 3, so the cube at index 3 moves into the temp box. The cube at index 4 shifts over to gain an index of 3 and the cube in the temp box gains an index of 4. The end moves in front of index 4 and the loop restarts.", "The cube at index 1 has more pieces out of place than the cube at index 0, so the cube at index 0 moves into the temp box. The cube at index 1 shifts over to gain an index of 0 and the cube in the temp box gains an index of 1.", "The cubes at index 1 and 2 are in the correct order (most to least pieces out of place) so no changes are made.", "The cube at index 3 has more pieces out of place than the cube at index 2, so the cube at index 2 moves into the temp box. The cube at index 3 shifts over to gain an index of 2 and the cube in the temp box gains an index of 3. The end moves in front of index 3, and the loop restarts.", "The cubes at index 0 and 1 are in the correct order (most to least pieces out of place) so no changes are made.", "The cube at index 2 has more pieces out of place than the cube at index 1, so the cube at index 1 moves into the temp box. The cube at index 2 shifts over to gain an index of 1 and the cube in the temp box gains an index of 2. The end moves in front of index 2, and the loop restarts again.", "The cubes at index 0 and 1 are in the correct order (most to least pieces out of place) so no changes are made.", "The cubes are now properly sorted!"];

  table = new Table(440, 375, 780, 100);
  buzzer = new Buzzer(428, 385);
  end = new End();
  iVariable = new IVariable();
  cubes[0] = new Cube4(150, 325);
  cubes[1] = new Cube2(225, 325);
  cubes[2] = new Cube3(300, 325);
  cubes[3] = new Cube(375, 325);
  cubes[4] = new Cube5(450, 325);
  cubes[5] = new Cube6(525, 325);
  cubes[6] = new Cube7(600, 325);
  cubes[7] = new Cube8(675, 325);
  cubes[8] = new Cube9(750, 325);
  pointer = new Pointer(460, 110);
  guide = new tourGuide();
  tempBox = new TempBox();
  //Obtaining cube coordinates and saving in array
  for (let i = 0; i < cubes.length; i++) {
    cubeCoordinates[i] = [];
    cubeCoordinates[i][0] = cubes[i].X;
    cubeCoordinates[i][1] = cubes[i].Y;
  }
  //Loading fonts
  speechBubble = new SpeechBubble("Hello");
  numbersText = loadFont("MonomaniacOne-Regular.ttf");
  buttonFont = loadFont("CarterOne-Regular.ttf");
  titleFont = loadFont("SundayMorning-BWqE3.otf");
  normalFont = loadFont("BreeSerif-Regular.ttf");
  codeImage = loadImage("Blah.png");
}

function draw() {
  background(221, 162, 225);
  screen.display();
  console.log (screen.screen);
}

class Screen {
  constructor(screen) {
    this.screen = screen;
    this.border = new Border();
    this.rubixCube1 = new ThreeDCube(200, 425);
    this.rubixCube2 = new ThreeDCube(700, 425);
  }

  display() {
    if (this.screen == "home") {
      background(192, 230, 249);
      fill(172, 100, 248);
      textFont(buttonFont);
      stroke(0);
      moveTimer++;
      textAlign(LEFT);
      //Drawing Start Button
      if (mouseX > 380 && mouseX < 520 && mouseY > 350 && mouseY < 405) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          this.screen = "start";
          moveTimer = 0;
        }
      }
      rect(380, 350, 140, 55);
      fill(0);
      textSize(33);
      noStroke();
      text("Start", 408, 388);
      fill(255);
      noStroke();
      //Drawing background banner
      rect(100, 70, 700, 150);
      triangle(100, 70, 30, 70, 100, 145);
      triangle(100, 145, 30, 220, 100, 220);
      triangle(800, 70, 870, 70, 800, 145);
      triangle(800, 145, 870, 220, 800, 220);
      textFont(titleFont);
      fill(0, 0, 0);
      textSize(70);
      text("Cube Sort", 240, 170);
      textSize(21);
      fill(0);
      text("Created By: Eleanor Mascarenhas, Trish Nguyen, and", 95, 270, 800);
      text("Sakshi Goel", 370, 320);
      this.border.display();
      this.border.light();
      this.rubixCube1.display();
      this.rubixCube2.display();
    }

    if (this.screen == "start") {
      speechBubble.display(textArray[0], 17);
      behind(0, 0, 0, ""); //Draws background (table, temp box, character, code image, pointer) and animates cubes
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Start Button
      stroke(0);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed) {
          speechBubble.setTimer(0);
          this.screen = "first";
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Start", 775, 575);
      noStroke();
      guide.position.x = 50;
      guide.position.y = 217.5;
    }
    if (this.screen == "first") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[1], 16.5);
      textAlign(LEFT);
      behind(0, 1, 1, "end"); //Drawing background and animating cubes
      iVariable.display(150, 385);
      end.display(810, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next Button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "second";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "second") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[2], 17.5);
      behind(0, 0, 0, "same"); //Drawing background and animating cubes
      //Highlighter
      fill(218, 255, 26);
      rect(185, 285, 80, 80, 5);
      rect(260, 285, 80, 80, 5);
      iVariable.display(225, 385);
      end.display(810, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "third";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "third") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[3], 17.5);
      behind(0, 0, 0, "same"); //Drawing background and animating cubes
      //Highliter
      fill(218, 255, 26);
      rect(260, 285, 80, 80, 5);
      rect(335, 285, 80, 80, 5);
      iVariable.display(298, 385);
      end.display(810, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next Button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "fourth";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "fourth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[4], 17.5);
      behind(3, 4, 4, "swap"); //Drawing background and animating cubes
      iVariable.display(373, 385);
      end.display(810, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next Button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "fifth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "fifth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[5], 17);
      behind(3, 5, 5, "swap"); //Drawing background and animating cubes
      iVariable.display(448, 385);
      end.display(810, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next Button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "sixth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "sixth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[6], 16.7);
      behind(3, 6, 6, "swap"); //Drawing background and animating cubes
      iVariable.display(523, 385);
      end.display(810, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next Button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "seventh";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "seventh") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[7], 16.8);
      behind(3, 7, 7, "swap");
      iVariable.display(598, 385);
      end.display(810, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next Button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "eigth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "eigth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[8], 15.5);
      behind(3, 8, 8, "swap"); //Drawing background and animating cubes
      end.display(810, 325);
      iVariable.display(673, 385);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "ninth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "ninth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[9], 17.5);
      behind(0, 0, 0, "endsame"); //Drawing background and animating cubes
      iVariable.display(150, 385);
      end.display(730, 325);
      //highliter
      fill(218, 255, 26);
      rect(110, 285, 80, 80, 5);
      rect(185, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "tenth";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "tenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[10], 17.5);
      behind(0, 0, 0, "same"); //Drawing background and animating cubes
      iVariable.display(225, 385);
      end.display(730, 325);
      //highliter
      fill(218, 255, 26);
      rect(260, 285, 80, 80, 5);
      rect(185, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next Button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "eleventh";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "eleventh") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[11], 16.5);
      behind(2, 4, 3, "swap"); //Drawing background and animating cubes
      iVariable.display(298, 385);
      end.display(730, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //Next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          moveTimer = 0;
          screenTimer = 0;
          this.screen = "twelfth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twelfth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[12], 17.5);
      behind(0, 0, 0, "same"); //Drawing background and animating cubes
      iVariable.display(373, 385);
      end.display(730, 325);
      //highliter
      fill(218, 255, 26);
      rect(335, 285, 80, 80, 5);
      rect(410, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirteenth";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "thirteenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[13], 16.5);
      behind(5, 6, 5, "swap");
      iVariable.display(448, 385);
      end.display(730, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "fourteenth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "fourteenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[14], 17.5);
      behind(5, 7, 6, "swap");
      iVariable.display(523, 385);
      end.display(730, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "fifteenth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "fifteenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[15], 16.5);
      behind(5, 8, 7, "swap");
      iVariable.display(598, 385);
      end.display(730, 325);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "sixteenth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "sixteenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[16], 17.5);
      behind(0, 0, 0, "endsame");
      iVariable.display(150, 385);
      end.display(655, 325);

      //highliter
      fill(218, 255, 26);
      rect(110, 285, 80, 80, 5);
      rect(185, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "seventeenth";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "seventeenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[17], 17.5);
      behind(0, 4, 2, "swap");
      iVariable.display(225, 385);
      end.display(655, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "eighteenth";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "eighteenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[18], 17.5);
      behind(0, 0, 0, "same");
      iVariable.display(298, 385);
      end.display(655, 325);
      //highliter
      fill(218, 255, 26);
      rect(260, 285, 80, 80, 5);
      rect(335, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "nineteenth";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "nineteenth") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[19], 17.5);
      behind(2, 6, 4, "swap");
      iVariable.display(373, 385);
      end.display(655, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twenty";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twenty") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[20], 17.5);
      behind(2, 7, 5, "swap");
      iVariable.display(448, 385);
      end.display(655, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentyone";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentyone") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[21], 17);
      behind(2, 8, 6, "swap");
      iVariable.display(523, 385);
      end.display(655, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentytwo";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentytwo") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[22], 17.5);
      behind(1, 4, 1, "end");
      iVariable.display(150, 385);
      end.display(580, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentythree";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentythree") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[23], 17.5);
      behind(0, 0, 0, "same");
      iVariable.display(225, 385);
      end.display(580, 325);

      //highliter
      fill(218, 255, 26);
      rect(185, 285, 80, 80, 5);
      rect(260, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentyfour";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentyfour") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[24], 17.5);
      behind(0, 6, 3, "swap");
      iVariable.display(298, 385);
      end.display(580, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentyfive";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentyfive") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[25], 17.5);
      behind(0, 7, 4, "swap");
      iVariable.display(373, 385);
      end.display(580, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentysix";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentysix") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[26], 17);
      behind(0, 8, 5, "swap");
      iVariable.display(448, 385);
      end.display(580, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentyseven";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentyseven") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[27], 17.5);
      behind(0, 0, 0, "endsame");
      iVariable.display(150, 385);
      end.display(505, 325);
      //highliter
      fill(218, 255, 26);
      rect(110, 285, 80, 80, 5);
      rect(185, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentyeight";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentyeight") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[28], 17.5);
      behind(1, 6, 2, "swap");
      iVariable.display(225, 385);
      end.display(505, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "twentynine";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "twentynine") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[29], 17.5);
      behind(1, 7, 3, "swap");
      iVariable.display(298, 385);
      end.display(505, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirty";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "thirty") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[30], 17.5);
      behind(1, 8, 4, "swap");
      iVariable.display(373, 385);
      end.display(505, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirtyone";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "thirtyone") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[31], 17.5);
      behind(4, 6, 1, "end");
      iVariable.display(150, 385);
      end.display(430, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirtytwo";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "thirtytwo") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[32], 17.5);
      behind(0, 0, 0, "same");
      iVariable.display(225, 385);
      end.display(430, 325);
      //highlight
      fill(218, 255, 26);
      rect(185, 285, 80, 80, 5);
      rect(260, 285, 80, 80, 5);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirtythree";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "thirtythree") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[33], 17.5);
      behind(7, 8, 3, "swap");
      iVariable.display(298, 385);
      end.display(430, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirtyfour";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "thirtyfour") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[34], 17.5);
      behind(0, 0, 0, "endsame");
      iVariable.display(150, 385);
      end.display(355, 325);

      fill(218, 255, 26);
      rect(110, 285, 80, 80, 5);
      rect(185, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirtyfive";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "thirtyfive") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[35], 17.5);
      behind(4, 8, 2, "swap");
      iVariable.display(225, 385);
      end.display(355, 325);

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 420) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "thirtysix";
          speechBubble.setTimer(0);
        }
      }
      if (moveTimer < 420) {
        fill(194, 199, 206);
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }    if (this.screen == "thirtysix") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[36], 17.5);
      behind(0, 0, 0, "endsame");
      iVariable.display(150, 385);
      end.display(280, 325);
      //highliter
      fill(218, 255, 26);
      rect(110, 285, 80, 80, 5);
      rect(185, 285, 80, 80, 5);
      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }

      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "sorted";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "sorted") {
      moveTimer++;
      screenTimer++;
      speechBubble.display(textArray[37], 17.5);
      behind(0, 0, 0, "done");

      for (let i = 0; i < cubes.length; i++) {
        cubes[i].display();
      }
      //next button
      stroke(0);
      strokeWeight(3);
      fill(172, 100, 248);
      if (mouseX > 750 && mouseX < 890 && mouseY > 535 && mouseY < 590) {
        fill(146, 71, 225);
        if (mouseIsPressed && moveTimer > 30) {
          screenTimer = 0;
          moveTimer = 0;
          this.screen = "end";
          speechBubble.setTimer(0);
        }
      }
      rect(750, 535, 140, 55);
      textFont(buttonFont);
      noStroke();
      fill(0);
      textSize(33);
      text("Next", 782, 575);
      noStroke();
    }
    if (this.screen == "end") {
      background(252, 162, 212);
      textFont(titleFont);
      fill(0);
      stroke(255);
      textSize(60);
      textAlign(CENTER);
      text("We hope you", 450, 110);
      text("learned something :)", 450, 220);
      this.border.display2();
      this.border.light2();
      fill(172, 100, 248);
      textFont(buttonFont);
      stroke(0);
      if (mouseX > 340 && mouseX < 550 && mouseY > 350 && mouseY < 455) {
        fill(146, 71, 225);
        if (mouseIsPressed) {
          this.screen = "home";
          resetCubes();
        }
      }
      rect(340, 350, 210, 105);
      fill(0);
      textSize(60);
      noStroke();
      text("Home", 444, 420);
      //this.rubixCube1.display();
      this.rubixCube2.display();
      guide.position.x = 190;
      guide.position.y = 320;
      noStroke();
      guide.display();
    }
  }
}
  
//Border class creates a border for the home and end screen. The lights in the border change every second.
class Border {
  constructor() {
    this.x = 10;
    this.y = 7;
  }
  display() {
    fill(252, 162, 212);
    rect(0, 0, 900, 15);
    rect(0, 0, 15, 600);
    rect(0, 585, 900, 15);
    rect(885, 0, 15, 600);
  }
  light() {
    if (frameCount % 60 == 0) {
      // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
      timer--;
    }
    if (timer % 2 == 0) {
      stroke("yellow");
      fill("yellow");
    } else {
      fill(40, 105, 236);
      stroke(40, 105, 236);
    }
    for (let i = 0; i < 900; i += 20) {
      circle(this.x + i, this.y, 5);
    }
    for (let i = 20; i < 600; i += 20) {
      circle(this.x - 3, this.y + i, 5);
    }
    for (let i = 15; i < 900; i += 20) {
      circle(this.x + i, this.y + 586, 5);
    }
    for (let i = 23; i < 580; i += 20) {
      circle(this.x + 883, this.y + i, 5);
    }
  }
  display2() {
    noStroke();
    fill(192, 230, 249);
    rect(0, 0, width, 15);
    rect(0, 0, 15, height);
    rect(0, height - 15, width, 15);
    rect(width - 15, 0, 15, height);
  }
  light2() {
    strokeWeight(4);
    if (frameCount % 60 == 0) {
      timer--;
    }

    if (timer % 2 == 0) {
      stroke(10, 160, 55);
      fill(10, 160, 55);
    } else {
      fill(250, 210, 60);
      stroke(250, 210, 60);
    }

    for (let i = 0; i < 900; i += 20) {
      circle(this.x + i, this.y, 5);
    }
    for (let i = 20; i < 600; i += 20) {
      circle(this.x - 3, this.y + i, 5);
    }
    for (let i = 15; i < 900; i += 20) {
      circle(this.x + i, this.y + 586, 5);
    }
    for (let i = 23; i < 580; i += 20) {
      circle(this.x + 883, this.y + i, 5);
    }
  }
}

//Creates a 3D cube for home and end screen
class ThreeDCube {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  display() {
    noStroke();
    fill(0, 0, 0);
    //Blue Face
    quad(this.x, this.y - 25, this.x + 100, this.y - 50, this.x + 100, this.y + 75, this.x, this.y + 100);
    strokeJoin(ROUND);
    fill(0, 0, 255);
    stroke(0, 0, 255);
    strokeWeight(3);
    quad(this.x+5, this.y-21, this.x+30, this.y-27, this.x+30, this.y+5, this.x+5, this.y+11);
    quad(this.x+38, this.y-29, this.x+63, this.y-35, this.x+63, this.y-3, this.x+38, this.y+3);
    quad(this.x+71, this.y-37, this.x+94, this.y-43, this.x+94, this.y-10, this.x+71, this.y-5);
    quad(this.x+5, this.y+20, this.x+30, this.y+14, this.x+30, this.y+45, this.x+5, this.y+50)
    quad(this.x+39, this.y+12, this.x+63, this.y+6, this.x+63, this.y+37, this.x+39, this.y+43);
    quad(this.x+72, this.y+4, this.x+94, this.y-1, this.x+94, this.y+29, this.x+72, this.y+34)
    quad(this.x+5, this.y+59, this.x+30, this.y+54, this.x+30, this.y+86, this.x+5, this.y+92);
    quad(this.x+39, this.y+52, this.x+63, this.y+46, this.x+63, this.y+77, this.x+39, this.y+83);
    quad(this.x+72, this.y+43, this.x+94, this.y+38, this.x+94, this.y+68, this.x+72, this.y+74);
    //Red Face
    fill (0);
    noStroke();
    quad (this.x, this.y - 25, this.x, this.y + 100, this.x - 100, this.y + 75, this.x - 100, this.y - 50);
    fill(255, 0, 0);
    stroke(255, 0, 0);
    strokeWeight(3);
    quad(this.x-5, this.y-21, this.x-30, this.y-27, this.x-30, this.y+5, this.x-5, this.y+11);
    quad(this.x-38, this.y-28, this.x-63, this.y-34, this.x-63, this.y-3, this.x-38, this.y+3);
    quad(this.x-71, this.y-37, this.x-94, this.y-43, this.x-94, this.y-10, this.x-71, this.y-5);
    quad(this.x-5, this.y+20, this.x-30, this.y+14, this.x-30, this.y+45, this.x-5, this.y+50)
    quad(this.x-39, this.y+12, this.x-63, this.y+6, this.x-63, this.y+37, this.x-39, this.y+43);
    quad(this.x-72, this.y+4, this.x-94, this.y-1, this.x-94, this.y+29, this.x-72, this.y+34)
    quad(this.x-5, this.y+59, this.x-30, this.y+54, this.x-30, this.y+86, this.x-5, this.y+92);
    quad(this.x-39, this.y+52, this.x-63, this.y+46, this.x-63, this.y+77, this.x-39, this.y+83);
    quad(this.x-72, this.y+43, this.x-94, this.y+38, this.x-94, this.y+68, this.x-72, this.y+74);
    //Yellow Face
    noStroke();
    fill (255, 200, 0);
    quad (this.x - 100, this.y - 50, this.x, this.y - 25, this.x + 100, this.y - 50, this.x, this.y - 75);
    stroke(0);
    strokeWeight(4);
    line(this.x, this.y - 27, this.x + 95, this.y - 51);
    line(this.x, this.y - 27, this.x - 95, this.y - 51);
    line(this.x - 97, this.y - 50, this.x, this.y - 73);
    line(this.x, this.y - 73, this.x + 97, this.y - 51);
    line(this.x + 30, this.y - 36, this.x - 60, this.y - 57);
    line(this.x + 61, this.y - 44, this.x - 30, this.y - 65);
    line(this.x - 30, this.y - 36, this.x + 60, this.y - 58);
    line(this.x - 61, this.y - 44, this.x + 29, this.y - 65);
  }
}

//Parent class of all the Rubik's cubes
class Cube {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  display() {
    noStroke();
    fill(0);
    rect(this.x - 35, this.y - 35, 70, 70, 5);
    fill("blue");
    square(this.x - 34, this.y - 34, 22, 5);
    square(this.x - 11, this.y - 34, 22, 5);
    square(this.x + 12, this.y - 34, 22, 5);
    square(this.x - 34, this.y - 11, 22, 5);
    square(this.x - 11, this.y - 11, 22, 5);
    square(this.x + 12, this.y + 12, 22, 5);
    square(this.x - 34, this.y + 12, 22, 5);
    square(this.x - 11, this.y + 12, 22, 5);
    square(this.x + 12, this.y - 11, 22, 5);
  }
  move(x, y) {
    if (this.x < x) {
      this.x += 2.5;
    }
    if (this.x > x) {
      this.x -= 2.5;
    }
    if (this.y < y) {
      this.y += 1;
    }
    if (this.y > y) {
      this.y -= 1;
    }
  }
  get X() {
    return this.x;
  }
  get Y() {
    return this.y;
  }
  set coordinates (coordinates) {
    this.x = coordinates[0];
    this.y = coordinates[1];
  }
}

//Inherited class from Cube class
class Cube2 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "1";
  }
  display() {
    super.display();
    fill(206, 14, 14); //red
    square(this.x - 34, this.y - 34, 22, 5);
    fill("white");
    square(this.x - 11, this.y - 11, 22, 5);
    fill(255, 154, 0); //orange
    square(this.x - 34, this.y + 12, 22, 5);
    fill(109, 255, 80); //green
    square(this.x - 11, this.y + 12, 22, 5);
    fill("blue");
  }
}

//Inherited class from Cube class
class Cube3 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "2";
  }
  display() {
    super.display();
    fill(249, 255, 36); //yellow
    square(this.x + 12, this.y - 34, 22, 5);
    fill(206, 14, 14); //red
    square(this.x - 34, this.y - 11, 22, 5);
  }
}

//Inherited class from Cube class
class Cube4 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "0";
  }
  display() {
    super.display();
    fill("white");
    square(this.x + 12, this.y + 12, 22, 5);
    fill(109, 255, 80); //green
    square(this.x - 11, this.y - 11, 22, 5);
    fill(255, 154, 0); //orange
    square(this.x - 34, this.y - 11, 22, 5);
  }
}

//Inherited class from Cube class
class Cube5 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "4";
  }
  display() {
    super.display();
    fill(206, 14, 14); //red
    square(this.x + 12, this.y + 12, 22, 5);
    fill(109, 255, 80); //green
    square(this.x + 12, this.y - 34, 22, 5);
    square(this.x - 34, this.y - 34, 22, 5);
    fill("white");
    square(this.x - 11, this.y - 11, 22, 5);
    fill(249, 255, 36); //yellow
    square(this.x - 11, this.y - 34, 22, 5);
    square(this.x - 34, this.y + 12, 22, 5);
  }
}

//Inherited class from Cube class
class Cube6 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "5";
  }
  display() {
    super.display();
    fill(255, 154, 0); //orange
    square(this.x - 11, this.y - 11, 22, 5);
  }
}

//Inherited class from Cube class
class Cube7 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "6";
  }
  display() {
    super.display();
    fill(206, 14, 14); //red
    square(this.x - 11, this.y - 11, 22, 5);
    square(this.x - 11, this.y + 12, 22, 5);
    fill(255, 154, 0); //orange
    square(this.x - 34, this.y - 34, 22, 5);
    square(this.x - 34, this.y + 12, 22, 5);
    fill(109, 255, 80); //green
    square(this.x - 11, this.y - 34, 22, 5);
    square(this.x + 12, this.y - 11, 22, 5);
    fill("white");
    square(this.x + 12, this.y - 34, 22, 5);
    fill(249, 255, 36); //yellow
    square(this.x + 12, this.y + 12, 22, 5);
  }
}

//Inherited class from Cube class
class Cube8 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "7";
  }
  display() {
    super.display();
    fill("white");
    square(this.x - 34, this.y + 12, 22, 5);
    fill(255, 154, 0); //orange
    square(this.x - 34, this.y - 11, 22, 5);
    fill(249, 255, 36); //yellow
    square(this.x - 11, this.y - 11, 22, 5);
    fill(109, 255, 80); //green
    square(this.x - 11, this.y - 34, 22, 5);
    fill(206, 14, 14); //red
    square(this.x + 12, this.y - 34, 22, 5);
  }
}

//Inherited class from Cube class
class Cube9 extends Cube {
  constructor(x, y) {
    super(x, y);
    this.x = x;
    this.y = y;
    this.num = "8";
  }
  display() {
    super.display();
    fill(109, 255, 80); //green
    square(this.x - 11, this.y - 11, 22, 5);
    fill(249, 255, 36); //yellow
    square(this.x + 12, this.y + 12, 22, 5);
    fill(206, 14, 14); //red
    square(this.x + 12, this.y - 11, 22, 5);
    square(this.x - 34, this.y - 11, 22, 5);
    fill("white");
    square(this.x - 34, this.y - 34, 22, 5);
    fill(255, 154, 0); //orange
    square(this.x - 11, this.y - 34, 22, 5);
    square(this.x - 34, this.y + 12, 22, 5);
  }
}

//Creates a buzzer for the background of the animation
class Buzzer {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  display() {
    fill("red");
    circle(this.x + 22, this.y, 44);
    fill(0);
    rect(this.x, this.y, 44, 30);
    fill(255);
    noStroke();
    rect(this.x, this.y, 44, 7.5);
  }
}

//Creates a table for the background of the animation
class Table {
  constructor(x, y, r, d) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.d = d;
  }
  display() {
    //table legs
    fill(195, 136, 36);
    stroke(146, 106, 35);
    strokeWeight(7);
    rect(this.x - 390, this.y, 10, 220);
    rect(this.x + 380, this.y, 10, 220);
    rect(this.x - 180, this.y + 45, 10, 150);
    rect(this.x + 170, this.y + 45, 10, 150);

    //table top
    strokeWeight(9);
    ellipse(this.x, this.y, this.r, this.d);
  }
}

//Creates a pointer that identfies the line of code that coincides with the animation
class Pointer {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display(x, y) {
    this.x = x;
    this.y = y;
    fill(5, 120, 30);
    stroke(255);
    strokeWeight(1);
    beginShape();
    vertex(this.x - 12.5, this.y - 12.5);
    vertex(this.x + 12.5, this.y);
    vertex(this.x - 12.5, this.y + 12.5);
    vertex(this.x - 6.25, this.y);
    vertex(this.x - 12.5, this.y - 12.5);
    endShape();
  }
  move() {
    this.y = 115;
  }
}

//Creates a guide character for display
class tourGuide {
  constructor() {
    this.position = new p5.Vector(50, 230);
  }
  display() {
    fill(227, 180, 113);
    ellipse(this.position.x, this.position.y, 100, 120);
    ellipse(this.position.x + 50, this.position.y - 8, 20, 40);
    ellipse(this.position.x - 50, this.position.y - 8, 20, 40);
    fill(140, 107, 60);
    angleMode(DEGREES);
    arc(this.position.x, this.position.y - 30, 80, 60, 180, 360);
    triangle(
      this.position.x - 30,
      this.position.y - 30,
      this.position.x - 40,
      this.position.y - 36,
      this.position.x - 50,
      this.position.y
    );
    triangle(
      this.position.x + 32,
      this.position.y - 50,
      this.position.x - 20,
      this.position.y - 20,
      this.position.x - 10,
      this.position.y - 40
    );
    arc(this.position.x + 44, this.position.y - 16, 20, 30, 90, 270);
    triangle(
      this.position.x + 44,
      this.position.y - 30,
      this.position.x + 8,
      this.position.y - 20,
      this.position.x + 20,
      this.position.y - 50
    );
    fill(0);
    ellipse(this.position.x - 20, this.position.y - 2, 14);
    ellipse(this.position.x + 16, this.position.y - 2, 14);
    fill(255);
    ellipse(this.position.x - 19, this.position.y - 1, 6);
    ellipse(this.position.x + 15, this.position.y - 1, 6);
    noFill();
    stroke(0);
    strokeWeight(2);
    arc(this.position.x - 20, this.position.y - 10, 14, 14, 220, 300);
    arc(this.position.x + 16, this.position.y - 10, 14, 14, 220, 300);
    line(
      this.position.x - 4,
      this.position.y + 12,
      this.position.x - 8,
      this.position.y + 24
    );
    line(
      this.position.x - 8,
      this.position.y + 24,
      this.position.x - 4,
      this.position.y + 24
    );
    arc(this.position.x - 2, this.position.y + 38, 20, 14, 5, 160);
    fill(227, 180, 113);
    noStroke();
    rect(this.position.x - 12, this.position.y + 48, 18, 32);
    stroke(40, 165, 15);
    strokeWeight(6);
    arc(this.position.x - 3, this.position.y + 70, 18, 12, 0, 180);
    fill(40, 165, 15);
    arc(this.position.x - 24, this.position.y + 120, 40, 100, 180, 270);
    arc(this.position.x + 14, this.position.y + 120, 40, 100, 270, 360);
    rect(this.position.x - 24, this.position.y + 70, 38, 90);
    fill(107, 166, 226);
    noStroke();
    rect(this.position.x - 27, this.position.y + 160, 44, 80);
    stroke(0);
    strokeWeight(1);
    line(
      this.position.x - 5,
      this.position.y + 162,
      this.position.x - 5,
      this.position.y + 240
    );
    fill(227, 180, 113);
    noStroke();
    rect(this.position.x + 17, this.position.y + 120.2, 18, 40);
    rect(this.position.x - 43, this.position.y + 120.2, 18, 40);
    arc(this.position.x - 34, this.position.y + 158, 18, 38, 0, 180);
    arc(this.position.x + 26, this.position.y + 158, 18, 38, 0, 180);
    stroke(0);
    noFill();
    arc(this.position.x - 24, this.position.y + 172, 20, 20, 150, 230);
    arc(this.position.x + 16, this.position.y + 172, 20, 20, 300, 400);
    fill(79, 51, 3);
    noStroke();
    quad(
      this.position.x - 27,
      this.position.y + 240,
      this.position.x + 17,
      this.position.y + 240,
      this.position.x + 26,
      this.position.y + 260,
      this.position.x - 36,
      this.position.y + 260
    );
    stroke(0);
    strokeWeight(1);
    line(
      this.position.x - 5,
      this.position.y + 240,
      this.position.x - 5,
      this.position.y + 260
    );
  }
}

//Draws temp box for animation
class TempBox {
  constructor() {
    this.x = 400;
    this.y = 450;
  }
  display() {
    stroke(0);
    strokeWeight(3);
    fill(255);
    square(this.x, this.y, 100);
    textFont(buttonFont);
    fill(0);
    noStroke();
    textSize(25);
    text("temp", this.x + 15, this.y + 130);
  }
  get X() {
    return this.x;
  }
  get Y() {
    return this.y;
  }
}

//Draws speech bubble for animation
class SpeechBubble {
  constructor() {
    //this.message = message;
    this.position = new p5.Vector(40, 25);
    this.timer = 0;
  }
  display(message, size) {
    stroke(24, 95, 178);
    strokeWeight(3);
    fill(154, 210, 242, 170);
    strokeJoin(ROUND);
    rect(this.position.x, this.position.y, 400, 210, 10);
    noStroke();
    fill(0);
    textAlign(CENTER);
    textFont(normalFont);
    textSize(size);
    if (this.timer < message.length) {
      this.timer += 0.6;
      text(
        message.substring(0, this.timer),
        this.position.x + 25,
        this.position.y + 40,
        350,
        160
      );
    } else {
      text(message, this.position.x + 25, this.position.y + 40, 350, 160);
    }
  }
  setTimer(time) {
    this.timer = time;
  }
}

//Displays indexes of the cubes
function Indexs() {
  //indexes
  noStroke();
  textFont(numbersText);
  textSize(20);
  fill(0);
  for (let i = 0; i < 9; i++) {
    text(i, 143 + 75 * i, 275);
  }
}

//Stores objects and functions that are called in animation screens. Moves pointer and cubes.
function behind(temp, move, newIndex, step) {
  textAlign(LEFT);
  //floor
  fill(198, 198, 198);
  noStroke();
  rect(-10, 470, width + 200, 150);

  //code
  image(codeImage, 450, 20, 450, 220);

  noStroke();
  guide.display();
  table.display();
  tempBox.display();
  buzzer.display();
  if (step == "none") {
    pointer.display(450, 67);
  }
  if (step == "same") {
    pointer.display(510, 108);
  }
  if (step == "swap") {
    if (moveTimer < 30) {
      pointer.display(510, 108);
    }
    if (moveTimer > 30 && moveTimer < 60) {
      pointer.display(524, 123);
    }
    if (moveTimer > 60 && moveTimer < 180) {
      pointer.display(524, 137);
    }
    if (moveTimer > 180 && moveTimer < 255) {
      pointer.display(524, 152);
    }
    if (moveTimer > 255) {
      pointer.display(524, 165);
    }
  }
  if (step == "done") {
    pointer.display(480, 82);
  }
  if (step == "endsame") {
    if (moveTimer < 30) {
      pointer.display(480, 82);
    }
    if (moveTimer > 30 && moveTimer < 60) {
      pointer.display(480, 95);
    }
    if (moveTimer > 60) {
      pointer.display(510, 108);
    }
  }
  if (step == "end") {
    if (moveTimer < 30) {
      pointer.display(480, 82);
    }
    if (moveTimer > 30 && moveTimer < 60) {
      pointer.display(480, 95);
    }
    if (moveTimer > 60 && moveTimer < 90) {
      pointer.display(510, 108);
    }
    if (moveTimer > 90 && moveTimer < 120) {
      pointer.display(524, 123);
    }
    if (moveTimer > 120 && moveTimer < 180) {
      pointer.display(524, 137);
    }
    if (moveTimer > 180 && moveTimer < 255) {
      pointer.display(524, 152);
    }
    if (moveTimer > 255) {
      pointer.display(524, 165);
    }
  }

  if (!(temp == 0 && move == 0 && newIndex == 0)) {
    if (moveTimer < 180) {
      cubes[temp].move(tempBox.X + 50, tempBox.Y + 50);
    }
    if (moveTimer > 210) {
      cubes[move].move(
        cubeCoordinates[newIndex - 1][0],
        cubeCoordinates[newIndex - 1][1]
      );
    }
    if (moveTimer > 240) {
      cubes[temp].move(
        cubeCoordinates[newIndex][0],
        cubeCoordinates[newIndex][1]
      );
    }
  }
  Indexs();
}

//displays a red bar to indicate 'end'
class End {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  display(x, y) {
    fill("red");
    stroke("red");
    rect(x - 22, y - 50, 10, 100);
    textFont(normalFont);
    textSize(20);
    stroke(0);
    strokeWeight(0);
    fill(0);
    text("end", x - 30, y + 70);
  }
}

//displays an 'i' to indicate the start
class IVariable {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  display(x, y) {
    textFont(normalFont);
    textSize(25);
    stroke(0);
    strokeWeight(0);
    fill(0);
    text("i", x - 2, y + 3);
  }
}

//resets cubes and guide when program restarts
function resetCubes() {
  for (let i = 0; i < cubes.length; i++) {
    cubes[i].coordinates = cubeCoordinates[i];
  }
  guide.position.x = 50;
  guide.position.y = 230;
}
